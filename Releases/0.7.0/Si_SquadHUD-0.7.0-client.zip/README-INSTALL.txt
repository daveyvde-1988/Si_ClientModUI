Silica Mod Menu / SquadHUD 0.7.0 - CLIENT PACKAGE

Windows x64; compatibility baseline Silica Beta 0.9.47, Steam build 25179420,
MelonLoader 0.7.3-ci.2446 Open-Beta / net6. Other builds need review.

INSTALL
1. Close Silica. Install MelonLoader for the Silica CLIENT if necessary:
   https://github.com/LavaGang/MelonLoader.Installer#melonloader-installation
2. Open the game folder via Steam > Silica > Manage > Browse local files.
3. Back up any existing Mods/Si_SquadHUD.dll OUTSIDE Mods. Do not leave an
   older copy with another DLL name inside Mods.
4. Extract this ZIP into the Silica client folder, merging Mods.
   Final path: <Silica client>/Mods/Si_SquadHUD.dll
5. Start normally and join the host's dedicated server. Server companion
   0.7.0 is needed for the new menus. No server DLLs go on your client.

F6 once expands status; again opens the full menu. F7 records a snapshot.
The header is only visible inside a loaded match. UNITBALANCE is read only;
its search field is dark. A Generic admin can use Admin -> Unit Balance ->
CONFIGURE for the native /b-style mouse menu: choose entries, type values,
SET, and use the native Save/Cancel/Save+rebalance confirmations. Some native
switches apply immediately. BACK navigates up; ROOT cancels the UI selection.
Private Discord configuration stays in native chat. Reload keeps the native
mod's configured auto-post behavior.

Admin -> Starter Units -> CONFIGURE edits faction/wildlife armies and 4-way
cross-spawn rules. Confirmed saves have server backups and apply next round;
this does not spawn extra live units or install a new gameplay mod.

Read-only public balance data remains cached on connection/reload. Admin
clicks request only current menu entries; unchanged catalog polls use small
acknowledgements. Older clients should update to get these improvements.

Native Unit Balance OFF is its enabled flag, not a full unload of every
independent rule. Settings/gameplay DLLs are provided by the host. No host
JSON, credentials, logs, profiles, game files or MelonLoader binaries are in
this package. New runtime behavior still awaits host-owned live verification.

UNINSTALL / ROLLBACK
Close Silica, remove Mods/Si_SquadHUD.dll, restore your previous DLL if needed.
Keep other mods and UserData. Logs: MelonLoader/Latest.log and
UserData/Si_SquadHUD/session-*.log.