using System;
using System.Collections.Generic;
using System.Linq;
using Silica.AI;
using UnityEngine;

namespace Si_Formation
{
    public sealed partial class Formations
    {
        private sealed class RetryUnit
        {
            internal Unit Unit;
            internal AIGroup Group;
            internal uint[] Orders;
        }
        private sealed class PlacementRetry
        {
            internal Player Player;
            internal Team Team;
            internal AIGroup Group;
            internal bool Commander;
            internal string Function;
            internal FormationDefinition Definition;
            internal Vector3 Centre,Forward,TravelForward;
            internal AgentMoveSpeed Speed;
            internal int Attempt;
            internal float NextAttempt;
            internal AttackOperation Attack;
            internal SoftGroup Soft;
            internal bool TwoStage;
            internal PlacementCache Cache;
            internal IEnumerator<bool> Search;
            internal readonly List<RetryUnit> Pending=new List<RetryUnit>();
            internal readonly List<Placement> Reserved=new List<Placement>();
        }
        private static readonly List<PlacementRetry> PlacementRetries=new List<PlacementRetry>();
        private static string UnitId(Unit u)=>u&&u.ObjectInfo?u.ObjectInfo.name:"";
        private static string PreferenceType(Unit u)=>u?EditorCategories.For(u.ObjectInfo):"None";
        private static IEnumerable<Unit> PlacementOrder(FormationDefinition f,IEnumerable<Unit> units)
            =>units.Select(u=>new {Unit=u,Match=f.Specificity(UnitId(u),PreferenceType(u))})
                .OrderBy(v=>v.Match.Item1).ThenBy(v=>v.Match.Item2)
                .ThenByDescending(v=>v.Unit.PhysicalRadius).ThenBy(v=>v.Unit.GetInstanceID()).Select(v=>v.Unit);
        private static void QueuePlacementRetries(Player player,string function,FormationDefinition f,Unit[] units,
            List<Placement> issued,Vector3 centre,Vector3 forward,AgentMoveSpeed speed,AttackOperation attack=null)
        {
            foreach(var u in units)foreach(var old in PlacementRetries)old.Pending.RemoveAll(p=>p.Unit==u);
            var batch=new PlacementRetry {Player=player,Team=player.Team,Group=player.Group,Commander=player.IsCommander,
                Function=function,Definition=f,Centre=centre,Forward=forward,Speed=speed,Attack=attack,
                TravelForward=Heading(centre-units.Aggregate(Vector3.zero,(sum,u)=>sum+u.transform.position)/units.Length)};
            batch.Soft=RememberSelection(player,function,f,units,forward);
            if(attack!=null)batch.Soft.Slots.Clear(); // New approach: choose nearby valid slots again.
            batch.Reserved.AddRange(issued);
            foreach(var unit in units.Where(u=>!issued.Any(p=>p.Unit==u)))
                batch.Pending.Add(new RetryUnit {Unit=unit,Group=unit.AIGroup,Orders=unit.OrderAgent.Orders.Select(o=>o.Id).ToArray()});
            if(batch.Pending.Count>0){PlacementRetries.Add(batch);PrepareInitialMove(batch);}
        }
        private static void ClearOrders(){ClearFpsTravel();ClearFpsMoveTasks();ClearRally();ClearLocks();Operations.Clear();PlacementRetries.Clear();SoftGroups.Clear();SoftMotions.Clear();DepartureSpeeds.Clear();SoftSpeedCaps.Clear();}
        private static bool BatchCurrent(PlacementRetry b)=>b.Player&&Player.Players.Contains(b.Player)&&b.Player.Team==b.Team&&b.Player.IsCommander==b.Commander&&
            (b.Commander||b.Player.Group==b.Group)&&FunctionActive(b.Player,b.Function)&&Selected(b.Player,b.Function)==b.Definition&&
            (b.Attack==null||Operations.Contains(b.Attack));
        private static bool PendingCurrent(PlacementRetry b,Unit unit)
        {
            var p=b.Pending.FirstOrDefault(v=>v.Unit==unit);
            return p!=null&&Available(unit)&&unit.Team==b.Team&&unit.AIGroup==p.Group&&
                (unit.OrderAgent.Orders.Count==0||p.Orders.SequenceEqual(unit.OrderAgent.Orders.Select(o=>o.Id)));
        }
        private static int placementCursor;
        private static void TickPlacementRetries()
        {
            if(PlacementRetries.Count==0)return;
            var clock=System.Diagnostics.Stopwatch.StartNew();
            for(int work=0,steps=0;work<12&&steps<1024&&clock.ElapsedMilliseconds<2&&PlacementRetries.Count>0;steps++)
            {
                var batch=PlacementRetries[(placementCursor++&int.MaxValue)%PlacementRetries.Count];
                if(!BatchCurrent(batch)){batch.Search?.Dispose();PlacementRetries.Remove(batch);SoftMotions.RemoveAll(m=>m.Batch==batch);continue;}
                if(batch.Reserved.RemoveAll(p=>!Available(p.Unit)||p.Unit.Team!=batch.Team)>0)
                {batch.Search?.Dispose();batch.Search=null;batch.Attempt=Math.Max(0,batch.Attempt-1);}
                batch.Pending.RemoveAll(p=>!PendingCurrent(batch,p.Unit));
                if(batch.Pending.Count==0){FinishPlacement(batch);continue;}
                if(batch.TwoStage)
                {
                    int initial=TickInitialMove(batch);
                    if(initial!=0){if(initial>0)work+=initial;continue;}
                }
                if(Time.unscaledTime<batch.NextAttempt)continue;
                if(batch.Search==null)
                {
                    batch.Attempt++;
                    if(batch.Cache==null)batch.Cache=new PlacementCache(batch.Definition,batch.Centre,batch.Forward,batch.Soft.Mirrored,
                        candidateAllowed:batch.Attack==null?(Func<Unit,int,bool>)null:(u,index)=>
                            Vector3.Dot(Flat(World(batch.Definition.Slots[index],batch.Definition,batch.Centre,batch.Forward,batch.Soft.Mirrored)-batch.Centre),batch.TravelForward)<=0.01f,
                        nearestFirst:batch.Attack!=null);
                    batch.Search=SearchRemembered(batch.Soft.Slots,batch.Definition,batch.Pending.Select(p=>p.Unit).ToArray(),batch.Centre,batch.Forward,batch.Reserved,
                        u=>PendingCurrent(batch,u),p=>IssuePlacement(batch,p),batch.Soft.Mirrored,batch.Cache).GetEnumerator();
                }
                if(batch.Search.MoveNext()){if(batch.Search.Current)work++;continue;}
                batch.Search.Dispose();batch.Search=null;
                if(batch.Pending.Count==0||batch.Attempt>=3)FinishPlacement(batch);
                else batch.NextAttempt=Time.unscaledTime+1.5f;
            }
        }
        private static bool IssuePlacement(PlacementRetry batch,Placement p)
        {
            if(!PendingCurrent(batch,p.Unit))return false;
            batch.Soft.Slots[p.Unit]=p.Slot;
            SoftMotions.Add(new SoftMotion {Batch=batch,Placement=p,Group=p.Unit.AIGroup,
                Previous=p.Unit.OrderAgent.Orders.Select(o=>o.Id).ToArray(),Departure=batch.TwoStage?Time.unscaledTime:float.PositiveInfinity});
            batch.Pending.RemoveAll(v=>v.Unit==p.Unit);
            return true;
        }
        private static void FinishPlacement(PlacementRetry batch)
        {
            PlacementRetries.Remove(batch);batch.Search?.Dispose();batch.Search=null;
            foreach(var motion in SoftMotions.Where(m=>m.Batch==batch&&m.Initial).ToArray())
            {SoftMotions.Remove(motion);RemoveDepartureUnit(motion.Placement.Unit);}
            StartSoftDepartures(batch);
            if(batch.Attack!=null&&BatchCurrent(batch))
            {
                foreach(var pending in batch.Pending.Where(p=>PendingCurrent(batch,p.Unit)).ToArray())
                {
                    var u=pending.Unit;
                    if(!ValidTarget(batch.Attack.Target))continue;
                    var intent=new OrderTarget(batch.Attack.Target.transform.position,batch.Attack.Target);
                    var parameters=OrderIssueParams.Commanded(batch.Speed);
                    generatedDepth++;
                    try {u.OrderAgent.IssueOrder(OrderDefinitionRegistry.Attack,in intent,in parameters);}
                    finally {generatedDepth--;}
                    batch.Soft.Slots.Remove(u);RemoveFpsTravelUnit(u);
                }
            }
            if(batch.Pending.Count>0)Trace(batch.Reserved.Count+" units placed; "+batch.Pending.Count+" remain on their previous/native orders after three passes.");
        }
    }
}
