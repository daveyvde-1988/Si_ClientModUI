Silica Mod Menu / SquadHUD 0.5.0 - CLIENT PACKAGE

For a friend joining the existing dedicated server.

Compatibility baseline
- Windows x64 Silica client Beta 0.9.47 (reference Steam build 25179420).
- Built against MelonLoader 0.7.3-ci.2446 Open-Beta, net6 runtime.
- Other game/loader versions have not been verified.
- Server needs SquadHUD companion 0.5.0. The existing host has it installed.
- Formation features use the host's Formation 2.15.1.
- Latest 0.5.0 UI changes have build/install verification; live testing is pending.

Install
1. Close Silica.
2. If MelonLoader is not installed, use its official installer for the Silica client:
   https://github.com/LavaGang/MelonLoader.Installer#melonloader-installation
   Locate Silica.exe via Steam > Silica > Manage > Browse local files.
   Match the compatibility baseline above where available. Loader/runtime setup:
   https://github.com/LavaGang/MelonLoader
3. If Mods/Si_SquadHUD.dll already exists, back it up OUTSIDE the Mods folder.
   Do not leave an older copy with a different DLL name inside Mods.
4. Extract this ZIP into the Silica CLIENT game folder, merging Mods.
   Final path: <Silica client folder>/Mods/Si_SquadHUD.dll
   Do not place it in Plugins, MelonLoader, or a nested Mods/Mods directory.
5. Start Silica normally and join the host's dedicated server.
6. The Mod menu header appears only in a loaded match. Press F6 once for
   status and again for the full menu. F7 records a status snapshot.
   Commander: Formations > Sidebar opens the draggable symbol strip.
   Drag the top grip; MENU/F6 returns to the full menu; X closes the strip.

No server DLLs are installed on the friend's client. Ranks, Formation,
AntiGrief and the wallet are provided by the host. Client Diagnostics is
optional and is not required or included. Preferences/placement are created
locally for the friend; no host settings or Steam-user profiles are bundled.

Uninstall / rollback
Close Silica, remove Mods/Si_SquadHUD.dll, and restore any previous backed-up
version if desired. Do not delete other mods or the UserData folder.

If the menu does not appear
Check MelonLoader/Latest.log for 'Silica Squad HUD v0.5.0' and errors. HUD logs
are under UserData/Si_SquadHUD. Confirm client/server versions and that the
player has joined a loaded dedicated-server match. On other servers the
full menu needs a compatible companion and relevant server mods.

Package contents
- Mods/Si_SquadHUD.dll
- README-INSTALL.txt
- SHA256SUMS.txt

This archive contains only the custom HUD DLL and instructions; no game,
MelonLoader, server DLLs, settings, logs or account profiles are included.