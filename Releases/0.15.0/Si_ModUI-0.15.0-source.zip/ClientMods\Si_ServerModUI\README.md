# Si_ServerModUI 1.1.0

Optional Mono server addon for Si_ClientModUI 0.15.0. Ported from DrMuck's server backend, with the current client UI retained. Requires the server's Si_AdminMod and MelonLoader. Players without the client mod continue using ordinary chat.

With the server closed, copy `Mods/Si_ServerModUI.dll` from the server ZIP into its `Mods` folder. Retire any old `Si_SquadHUD_Server.dll` so only one UI companion runs. Do not put this Mono DLL on the IL2CPP client. The optional server is not required for singleplayer or standalone client functionality.

The addon discovers registered player commands, phrases and permitted admin commands. It pushes per-player hashed catalogs/diffs, captures synchronous replies addressed to the invoking player, and pushes vote events. Actual command authorization still runs through Si_AdminMod for every invocation. Broadcast and asynchronous output stays native. Capture overflow also stays native.

Configuration: `UserData/cfg/Si_ServerModUI/menu.json`, created on first startup and reloaded after edits. This retains the friend's labels, module ownership overrides, category/priority, navigation prefix, hidden commands, argument hints and match-control metadata. To reuse an existing friend's configuration, copy it from `UserData/cfg/SquadHUD/menu.json` before starting. It is not copied or overwritten by the installer.

Transport: native packet 126, marker `SiSquadHUD/2`. The marker is intentionally stable for wire compatibility. It disables itself if the game defines that packet type. Only subscribed clients receive addon traffic. Client sends bounded discovery hellos and explicit commands; the server checks catalogs every five seconds and sends changes only. The global outbox allows 160 packets/second, bursts of 16, maximum 8192 queued packets. Commands are serialized per player at 100 ms minimum and four queued maximum. No client heartbeats or ongoing catalog polling.

Admin diagnostic: `!hudtest` writes the caller's frame under this addon's config folder; `!hudtest /command` invokes the proxy and echoes captured output. This executes real commands and should be used deliberately. Nothing invokes it automatically.

Build from the workspace root:

```powershell
dotnet build ClientMods/Si_ServerModUI/Server/Si_ServerModUI.csproj -c Release --ignore-failed-sources
```

Reference path can be overridden with `-p:ServerRoot=<server directory>`. Packaging and optional verified installation are managed by `../Si_ClientModUI/Prepare-Release.ps1` and `../Si_ClientModUI/Install-ModUI.ps1 -Side server`. The client ZIP and server ZIP are separate. Neither has been deployed by this integration task.
